
<?php $__env->startSection('content'); ?>
    <main id="main" class="main p-0">
        <?php if(session('success')): ?>
            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    swal({
                            text:' تم تحديث بيانات الحساب',
                            content: true,
                            icon: "success",
                            classname: 'swal-IW',
                            timer: 1700,
                            buttons: false,
                        });
                });
            </script>
        <?php endif; ?>
        <div class="row m-0 py-5 justify-content-center in-bg-srface">
            <div class="col-8 rounded bg-white p-5 shadow ">
                <div class="row justify-content-center">
                    <div class="col-2">
                        <div class="account-picture d-flex flex-column align-items-center justify-content-center">
                            <div class="mb-3">
                                <img src="<?php echo e("https://www.gravatar.com/avatar/" . md5(strtolower(trim(Auth::user()->email))) . "?d=mp"); ?>" alt="Profile" class="rounded-circle">
                            </div>
                            <div class="">
                                <button class="btn fw-bold injaaz-btn" onclick="showChangePhotoModal()">تغيير الصورة</button>
                            </div>
                            <!--#region Add Memeber Modal-->
                                <div id="change-photo-modal" class="modal change-photo-modal"  tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-center" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header px-4">
                                                <button type="button" class="close injaaz-btn-close close-change-photo-modal" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>                        
                                            </div>
                                            <div class="modal-body">
                                                <h5>الصورة الظاهر تعتمد على حساب الإيميل المسجل على موقع gravatar اذا أردت تغيير الصورة قم بتغييرها من الموقع   <a target="_blank" href="https://www.gravatar.com">gravatar</a></h5>
                                            </div>
                                            <div class="modal-footer d-flex justify-content-center">
                                                <button class="btn btn-danger w-50 close-change-photo-modal">اغلاق</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <!--#endregion Add Memeber Modal-->
                        </div>
                    </div>
                    <div class="col-8">
                        <form method="POST" action="<?php echo e(route('account.settings.update', ['userId' => $user->id])); ?>" class="row g-3 needs-validation" novalidate>
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="user-name" class="form-label fw-bold">الأسم</label>
                                <input id="user-name" type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <div class="invalid-feedback">قم بادخال الأسم</div>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="user-email" class="form-label fw-bold">الأيميل</label>
                                <input id="user-email" type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <div class="invalid-feedback">قم بادخال الإيميل</div>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="user-phone" class="form-label fw-bold">رقم الهاتف</label>
                                <input id="user-phone" type="text" name="phone"  value="<?php echo e(old('phone', $user->phone)); ?>" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <div class="invalid-feedback">قم بادخال رقم هاتفك</div>
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="user-bio" class="form-label fw-bold">الوصف</label>
                                <textarea id="user-bio" name="bio" class="form-control" rows="7"><?php echo e(old('bio', $user->bio)); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="user-password" class="form-label fw-bold">كلمة السر الجديدة</label>
                                <input id="user-password" type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="user-confirm-password" class="form-label fw-bold">تأكيد كلمة السر الجديدة</label>
                                <input id="user-confirm-password" type="password" name="password_confirmation" class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 d-flex justify-content-center align-items-center">
                                <button class="btn injaaz-btn fw-bold px-5" type="submit">حفظ</button>
                            </div>

                            
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <script>
            function showChangePhotoModal() {
                var closeChangePhotoModal = $('.close-change-photo-modal');
                closeChangePhotoModal.each(function (index, closeBtn) {
                    $(closeBtn).on('click', function () {
                        $('#change-photo-modal').modal('hide');
                    });
                });

                $('#change-photo-modal').modal('show');
            }
        </script>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\My-Github\Injaaz\resources\views/dashboard/accountSettings.blade.php ENDPATH**/ ?>