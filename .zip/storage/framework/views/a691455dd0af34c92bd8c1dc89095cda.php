
<?php $__env->startSection('content'); ?>
    <main id="main" class="main p-0">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="head-title my-3">
                        <h2 class="text-center m-0">الأشعارت</h2>
                    </div>
                    <table class="table table-striped text-center">
                        <thead>
                            <th>
                                الأشعار 
                            </th>
                            <th>
                                التاريخ  
                            </th>
                            <th>
                                الحالة 
                            </th>
                            <th>
                               حذف
                            </th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <p><?php echo $notification->text; ?></p>
                                </td>
                                <td>
                                    <?php echo e($notification->created_at->format('Y/m/d h:i A')); ?>

                                </td>
                                <td>
                                    <?php if($notification->state == "reject"): ?>
                                        <div id="notification-state" class="col-7 d-flex gap-1 justify-content-between">
                                            <button disabled class="btn btn-danger fw-bold py-0 px-4">تم الرفض</button>
                                        </div>
                                    <?php elseif($notification->state == "confirm"): ?>
                                      <div id="notification-state" class="col-7 d-flex gap-1 justify-content-between">
                                        <button disabled class="btn btn-success fw-bold py-0 px-4">تمت الموافقة</button>
                                      </div>
                                    <?php else: ?>
                                        <div id="notification-state" class="col-7 d-flex gap-1 justify-content-between">
                                            <button class="btn btn-success fw-bold py-0 px-4" onclick="changeNotificationStatus(<?php echo e($notification->id); ?>,this,'confirm')">قبول</button>
                                            <button class="btn btn-danger fw-bold py-0 px-4" onclick="changeNotificationStatus(<?php echo e($notification->id); ?>,this,'reject')">رفض</button>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div>
                                        <i class="fa-solid fa-trash-can notification-delete-icon" onclick="deleteNotification(<?php echo e($notification->id); ?>,this)"></i>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\My-Github\Injaaz\resources\views/dashboard/notification.blade.php ENDPATH**/ ?>