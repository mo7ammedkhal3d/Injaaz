
<?php $__env->startSection('content'); ?>
        <form action="#" class="row">
    <div class="col-md-6">
        <div class="form-group">
        <label for="input_from">From</label>
        <input type="text" class="form-control" value="<?php echo e(date('Y/m/d')); ?>" id="input_from" placeholder="Start Date">
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
        <label for="input_from">To</label>
        <input type="text" class="form-control" id="input_to" placeholder="Start Date">
        </div>
    </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\My-Github\Injaaz\resources\views/dashboard/test.blade.php ENDPATH**/ ?>